<?php 
require '../index.php';