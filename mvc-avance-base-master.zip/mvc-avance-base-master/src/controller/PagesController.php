<?php

// PagesController.php

class PagesController {

    public function home() {

        view('pages.home');

    }
}