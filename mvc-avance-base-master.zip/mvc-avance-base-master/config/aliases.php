<?php

/**
 * Aliases
 */
class_alias('\Bramus\Router\Router', 'Router');